<?php

$page = $_GET['page'] ?? 'home';

echo $page;

print_r($_GET);

switch ($page) {
    case 'home':
        include_once 'Controller/c_home.php';
        break;
    case 'product':
        include_once 'Controller/c_product.php';
        break;
    case 'admin':
            include_once 'Controller/c_admin.php';
            break;    
    default:
        echo "Trang đang hoàn thiện ";
        break;
}

?>