<?php
include'view/admin/header.php';
include 'view/admin/catalog.php';
?>