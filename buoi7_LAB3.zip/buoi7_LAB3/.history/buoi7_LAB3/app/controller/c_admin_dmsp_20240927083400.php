<?php
include 'model/m_database.php';
//View
include 'view/admin/header.php';
include 'view/admin/catalog.php';
?>