<?php
include 'model/m_database.php';
include 'model/m_admin_dmsp.php';
$danhmuc = new m_admin_dmsp();
$dmsp = $danhmuc->getAllDM();
//View
include './buoi7_LAB3';
include 'view/admin/catalog.php';
?>