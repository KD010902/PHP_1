<?php
include 'model/m_database.php';
include 'model/m_admin_dmsp.php';
$danhmuc = new m_admin_dmsp();
$dmsp = $danhmuc->getAllDM();
//View
include 'view/admin/danhmuc.php';
include 'view/admin/product.php';
?>