<?php 
// if(!isset($_GET['page'])){
//      $page = 'home';
// } else $_GET['page'] = $page; 
// // $page = $_GET['page'] = $page;
include 'model/m_database.php';
$db = new database();
$db->conn;
include_once "View/user/header.php";
include_once "View/user/footer.php";
include_once "View/user/home.php";
?>