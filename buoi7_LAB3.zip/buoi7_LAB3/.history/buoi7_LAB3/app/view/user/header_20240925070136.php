<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Đơn Giản</title>
    <link rel="stylesheet" href="../public/user/css/style.css">
</head>
<body>

<header>
    <h1>Trang Chủ</h1>
</header>

<nav>
    <a href="../layout/index.html">Trang Chủ</a>
    <a href="">Sản phẩm</a>
    <a href="index.php?page=about.html">Giới Thiệu</a>
    <a href="../layout/contact.html">Liên Hệ</a>
</nav>