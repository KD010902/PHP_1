<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Đơn Giản</title>
    <link rel="stylesheet" href="../public/user/css/style.css">
</head>
<body>

<header>
    <h1>Trang Chủ</h1>
</header>

<nav>
    <a href="index.php">Trang Chủ</a>
    <a href="index.php?page=product">Sản phẩm</a>
    <a href="index.php?page=about">Giới Thiệu</a>
    <a href="index.php?page=contact">Liên Hệ</a>
    <a href="index.php?page=admin">Admin</a>
</nav>