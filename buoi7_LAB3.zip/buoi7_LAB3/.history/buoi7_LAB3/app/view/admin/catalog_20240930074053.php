<?php include_once 'header.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trang Quản Trị</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <h1>Trang Quản Trị</h1>
</header>

<nav>
    <ul>
        <li><a href="index.html">Trang Chủ</a></li>
        <li><a href="product.html">Sản phẩm</a></li>
        <li><a href="users.html">Người dùng</a></li>
        <li><a href="updateProduct.html">Form Cập nhật</a></li>
    </ul>
</nav>

<section>
    <div class="container">
        <div class="col3">
            <h2>Thêm Mới Danh Mục</h2>
            <form>
                <input type="text" placeholder="Tên danh mục">
                <input type="submit" value="Thêm">
            </form>
        </div>
        <div class="col9">
            <h2>Danh Sách Danh Mục</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên danh mục </th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    for($i=0;$i<count($dmsp);$i++){
                    ?>
                    <tr>
                        <td><?=$dmsp[$i]['id']?></td>
                        <td><?=$dmsp[$i]['name']?></td>
                        <td class="action-icons">
                            <a href="#"><i class="fas fa-edit"></i></a>
                            <a href="#"><i class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
            <?php } ?>
                    <!-- Các hàng khác -->
                </tbody>
            </table>
        </div>
    </div>
</section>

</body>
</html>
