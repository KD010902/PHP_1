<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<!-- Thêm thư viện Chart.js từ CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="../public/admin/css/style.css">
</head>
<body>
<header>
    <h1>Trang Quản Trị</h1>
</header>

<nav>
    <ul>
        <li><a href="home.php">Trang Chủ</a></li>
        <li><a href="product.php">Sản phẩm</a></li>
        <li><a href="users.html">Người dùng</a></li>
        <li><a href="updateProduct.html">Form Cập nhật</a></li>
    </ul>
</nav>