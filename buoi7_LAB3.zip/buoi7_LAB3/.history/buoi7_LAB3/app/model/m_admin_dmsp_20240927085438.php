<?php 
class m_admin_dmsp extends database{
    public $db
    public function __construct(){
        $this->db = new database;
    }
    public function getAllDM(){
        $sql
    }
    {
        
    }
}
?>