<?php 
class m_admin_dmsp extends Database {
    public $db;

    public function __construct() {
        parent::__construct(); 
        $this->db = new Database();
    }

    public function getAllDM() {
        $sql = "SELECT * FROM products"; 
        return $this->db->getAll($sql); 
    }
}
?>