<?php 
class Database {
    private $server = 'localhost';
    private $user = 'root';
    private $pass = '';
    private $dbname = 'hoangkhanhduy_ps27463_lab4_php';
    public $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host=$this->server;dbname=$this->dbname", $this->user, $this->pass);
            // Set the PDO error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Connected successfully";
        } catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function getAll($sql) {
        $stmt = $this->conn->prepare($sql); // Missing semicolon fixed
        $stmt->execute(); // Execute the query
        // Set the resulting array to associative
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        return $stmt->fetchAll(); // Fetch all results
    }
}
?>