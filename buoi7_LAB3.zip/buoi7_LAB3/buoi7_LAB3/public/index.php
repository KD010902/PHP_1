<?php  
header(header:'Location:app/index.php')
?>