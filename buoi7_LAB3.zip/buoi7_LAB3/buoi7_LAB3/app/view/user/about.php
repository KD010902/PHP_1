
<div class="container_cart">
    <div class="about-box">
        <p>Chào mừng bạn đến với trang giới thiệu. Chúng tôi là một website đơn giản với các sản phẩm mới nhất.</p>
    </div>
</div>