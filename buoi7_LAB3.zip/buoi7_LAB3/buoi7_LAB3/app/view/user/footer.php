<footer>&copy; 2023 Website Đơn Giản</footer>

</body>
</html>
