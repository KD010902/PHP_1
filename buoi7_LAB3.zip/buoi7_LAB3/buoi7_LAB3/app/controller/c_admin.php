<?php 
include_once "view/admin/header.php";
include_once "view/admin/home.php";
include_once "view/admin/footer.php";
?>