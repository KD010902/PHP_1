<?php 

include_once "View/user/header.php";
include_once "View/user/product.php";
include_once "View/user/home.php";

?>